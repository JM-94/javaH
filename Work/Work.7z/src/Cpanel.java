import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.CardLayout;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Cpanel extends JPanel{
	private JTextField textField;
	public Cpanel() {
		setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(67, 41, 97, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC99D\uAC00");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText(""+(Integer.parseInt(textField.getText())+1));
//				�ؽ�Ʈ�� ��������		���ڿ��� ����ȯ			��Ʈ������			�ؽ�Ʈ �޾ƿ���		1����
			}
		});
		btnNewButton_1.setBounds(219, 141, 97, 23);
		add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setText("0");
		textField.setBounds(79, 142, 116, 21);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(102, 241, 57, 15);
		add(lblNewLabel);
		
		JButton btnNewButton_2 = new JButton("\uAC10\uC18C");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(""+(Integer.parseInt(textField.getText())-1));
			}
		});
		btnNewButton_2.setBounds(219, 182, 97, 23);
		add(btnNewButton_2);
		
	}
	public static void main(String[] args) {
		new Cpanel();
	}
}