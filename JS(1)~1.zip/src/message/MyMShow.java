package message;

import javax.swing.JOptionPane;

public class MyMShow {

	public static void showMe(String message) {
		JOptionPane.showMessageDialog(null, message);
	}
}
