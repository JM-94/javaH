package JFrame;

public class Test_Main {
	public static void main(String[] args) {
		Select sel = new Select();
		sel.select();
	}
}
